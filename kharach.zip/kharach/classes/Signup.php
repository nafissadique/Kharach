<?php
require_once '../config.php';
class Signup extends DBConnection {
    private $settings;
    public function __construct()
    {
        global $_settings;
        $this->settings = $_settings;

        parent::__construct();
		ini_set('display_error', 1);
	}
	public function __destruct(){
		parent::__destruct();
	}
    
    public function signup(){
        extract($_POST);

        $qry = $this->conn->query("INSERT into users values");
    }
}